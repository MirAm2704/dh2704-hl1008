const KEY="myhub-v1";
const defaults={
 settings:{name:"MyHub",title:"Kho của tôi",subtitle:"Tổng hợp ứng dụng, tài liệu, công cụ và nguồn do bạn quản lý.",notice:"Chào mừng bạn đến kho cá nhân. Bạn có thể thêm nguồn, chỉnh nhạc và quản lý nội dung.",music:"",volume:.35,auto:false},
 items:[
  {id:1,title:"Website cá nhân",desc:"Trang chủ / portfolio của tôi",category:"Website",url:"https://example.com",image:""},
  {id:2,title:"Nguồn tài liệu",desc:"Kho tài liệu và liên kết hữu ích",category:"Tài liệu",url:"https://example.com",image:""},
  {id:3,title:"Công cụ online",desc:"Các công cụ tôi thường dùng",category:"Công cụ",url:"https://example.com",image:""}
 ]};
let data=JSON.parse(localStorage.getItem(KEY)||"null")||defaults;
const $=s=>document.querySelector(s);
const save=()=>localStorage.setItem(KEY,JSON.stringify(data));
let category="Tất cả";

function render(){
 $("#siteName").textContent=data.settings.name; $("#heroTitle").textContent=data.settings.title;
 $("#heroSubtitle").textContent=data.settings.subtitle; $("#noticeText").textContent=data.settings.notice;
 $("#itemCount").textContent=data.items.length;
 $("#sourceCount").textContent=new Set(data.items.map(x=>x.category)).size;
 const cats=["Tất cả",...new Set(data.items.map(x=>x.category))];
 $("#filters").innerHTML=cats.map(c=>`<button class="${c===category?"active":""}" data-cat="${esc(c)}">${c}</button>`).join("");
 renderItems(); renderAdmin();
}
function renderItems(){
 const q=$("#search").value.trim().toLowerCase();
 const filtered=data.items.filter(x=>(category==="Tất cả"||x.category===category)&&(`${x.title} ${x.desc} ${x.category}`.toLowerCase().includes(q)));
 const groups={}; filtered.forEach(x=>(groups[x.category]??=[]).push(x));
 $("#content").innerHTML=Object.keys(groups).length?Object.entries(groups).map(([cat,arr])=>`
 <div class="section-title"><h2>${esc(cat)}</h2><span>${arr.length} MỤC</span></div>
 <div class="grid">${arr.map(card).join("")}</div>`).join(""):`<div class="section-title"><h2>Không tìm thấy</h2></div><p class="muted">Thử từ khóa khác.</p>`;
}
function card(x){
 const img=x.image?`<img class="thumb" src="${esc(x.image)}" alt="">`:`<div class="thumb">✦</div>`;
 return `<article class="card"><div class="card-top">${img}<div><h3>${esc(x.title)}</h3><p>${esc(x.desc||"")}</p></div></div><span class="tag">${esc(x.category)}</span><a class="download" href="${esc(x.url)}" target="_blank" rel="noopener">MỞ NGUỒN ↗</a></article>`;
}
function renderAdmin(){
 $("#adminList").innerHTML=data.items.map(x=>`<div class="admin-item"><div class="thumb">✦</div><div><b>${esc(x.title)}</b><small>${esc(x.category)} · ${esc(x.url)}</small></div><button onclick="editItem(${x.id})">Sửa</button><button onclick="deleteItem(${x.id})">Xóa</button></div>`).join("");
}
function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
window.editItem=id=>{const x=data.items.find(i=>i.id===id);if(!x)return; $("#editId").value=x.id;$("#fTitle").value=x.title;$("#fDesc").value=x.desc;$("#fCategory").value=x.category;$("#fUrl").value=x.url;$("#fImage").value=x.image||"";$("#adminModal").classList.remove("hidden");};
window.deleteItem=id=>{if(confirm("Xóa mục này?")){data.items=data.items.filter(x=>x.id!==id);save();render()}};
$("#filters").addEventListener("click",e=>{if(e.target.dataset.cat){category=e.target.dataset.cat;render()}});
$("#search").addEventListener("input",renderItems); $("#clear").onclick=()=>{$("#search").value="";renderItems()};
$("#adminBtn").onclick=()=>{$("#adminModal").classList.remove("hidden");fillSettings()};
$("#adminClose").onclick=()=>$("#adminModal").classList.add("hidden");
document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));b.classList.add("active");$("#itemsTab").classList.toggle("hidden",b.dataset.tab!=="items");$("#settingsTab").classList.toggle("hidden",b.dataset.tab!=="settings")});
$("#resetForm").onclick=()=>$("#itemForm").reset();
$("#itemForm").onsubmit=e=>{e.preventDefault();const id=Number($("#editId").value)||Date.now();const obj={id,title:$("#fTitle").value.trim(),desc:$("#fDesc").value.trim(),category:$("#fCategory").value.trim(),url:$("#fUrl").value.trim(),image:$("#fImage").value.trim()};const i=data.items.findIndex(x=>x.id===id);i>=0?data.items[i]=obj:data.items.unshift(obj);save();e.target.reset();$("#editId").value="";render()};
function fillSettings(){const s=data.settings;$("#sName").value=s.name;$("#sTitle").value=s.title;$("#sSubtitle").value=s.subtitle;$("#sNotice").value=s.notice;$("#sMusic").value=s.music;$("#sVolume").value=s.volume;$("#sAuto").checked=s.auto}
$("#settingsForm").onsubmit=e=>{e.preventDefault();data.settings={name:$("#sName").value.trim()||"MyHub",title:$("#sTitle").value.trim()||"Kho của tôi",subtitle:$("#sSubtitle").value.trim(),notice:$("#sNotice").value.trim(),music:$("#sMusic").value.trim(),volume:Number($("#sVolume").value),auto:$("#sAuto").checked};save();setupAudio();render();alert("Đã lưu cài đặt.")};
const audio=$("#audio");let playing=false;
function setupAudio(){audio.src=data.settings.music||"";audio.volume=data.settings.volume??.35}
$("#musicBtn").onclick=async()=>{if(!audio.src){alert("Hãy vào ⚙️ Quản lý → Giao diện & nhạc và thêm URL MP3/OGG.");return}try{if(playing){audio.pause();playing=false;$("#musicBtn").classList.remove("active");$("#musicBtn").innerHTML="🎧 <span>Nhạc</span>"}else{await audio.play();playing=true;$("#musicBtn").classList.add("active");$("#musicBtn").innerHTML="🔊 <span>Tắt nhạc</span>"}}catch(e){alert("Không thể phát nguồn nhạc này. Hãy dùng URL file MP3/OGG trực tiếp.")}};
setupAudio();render();
