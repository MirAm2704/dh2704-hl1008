# MyHub — website kho cá nhân

Website tĩnh lấy cảm hứng từ bố cục ModGameios nhưng dùng dữ liệu riêng của bạn.

## Có sẵn
- Giao diện responsive cho iPhone/PC.
- Tìm kiếm và lọc theo danh mục.
- Thêm / sửa / xóa nguồn trực tiếp bằng nút **⚙️ Quản lý**.
- Chỉnh tên web, tiêu đề, mô tả, thông báo.
- Thêm URL nhạc MP3/OGG, chỉnh âm lượng, bật/tắt nhạc.
- Dữ liệu quản lý lưu bằng `localStorage`.

## Đưa lên GitHub Pages
1. Tạo repository mới trên GitHub.
2. Upload `index.html`, `style.css`, `app.js`.
3. Vào **Settings → Pages**.
4. Chọn branch `main` và thư mục `/root`.
5. Mở URL GitHub Pages được cấp.

## Thêm nhạc
Trong **⚙️ Quản lý → Giao diện & nhạc**, dán URL file âm thanh trực tiếp, ví dụ:
`https://ten-mien-cua-ban.com/music.mp3`

Không nên dùng link trang YouTube/SoundCloud thông thường làm URL audio; đó không phải file âm thanh trực tiếp.
